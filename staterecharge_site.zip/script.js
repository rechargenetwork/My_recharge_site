// Add your JavaScript here
console.log("Script loaded");
